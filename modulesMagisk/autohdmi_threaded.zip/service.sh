#!/system/bin/sh
# lancer hdmi.sh en tâche de fond, puis quitter immédiatement
/system/bin/sh /data/adb/modules/autohdmi/hdmi.sh &
exit 0
