#!/system/bin/sh

sleep 5

# On stocke l'état du dernier switch
LAST_STATE=0  # 0 = pas switché, 1 = déjà sur HDMI1

is_hdmi_connected() {
    STATE=$(dumpsys tv_input | grep "HdmiInputService/HW1" | grep "state: 0")
    if [ ! -z "$STATE" ]; then
        return 0    # connecté
    else
        return 1    # pas connecté
    fi
}

switch_to_hdmi() {
    am start -n com.softwinner.awsource/.MainActivity
    sleep 1
    input keyevent DPAD_CENTER
}

# Premier passage
if is_hdmi_connected; then
    switch_to_hdmi
    LAST_STATE=1
fi

# Boucle permanente
while true; do
    if is_hdmi_connected; then
        if [ "$LAST_STATE" = "0" ]; then
            switch_to_hdmi
            LAST_STATE=1
        fi
    else
        LAST_STATE=0
    fi
    sleep 2
done
