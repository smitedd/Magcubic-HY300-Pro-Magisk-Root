#!/system/bin/sh
# Magisk service script - runs in late_start service
MODDIR=${0%/*}

# Start daemon in background so we don't block Magisk service
sh "$MODDIR/firetv_ir_daemon.sh" &
