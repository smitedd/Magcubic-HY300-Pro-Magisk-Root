#!/system/bin/sh
# Fire TV IR remap daemon for HY300
# Listens to sunxi-ir raw events and maps Fire TV volume IR codes to Android volume keys.

LOGFILE=/data/local/tmp/firetv_ir_remap.log

log() {
    echo "[firetv_ir_remap] $(date '+%H:%M:%S') $*" >> "$LOGFILE"
}

# Find sunxi-ir input node dynamically
IR_NODE=$(grep -A5 'Name="sunxi-ir"' /proc/bus/input/devices | grep Handlers | sed 's/.*event\([0-9]\+\).*/\/dev\/input\/event\1/' | head -n1)
[ -z "$IR_NODE" ] && IR_NODE="/dev/input/event1"

log "Using IR node: $IR_NODE"

# Infinite loop with auto-recovery if getevent dies
while true; do
    if [ ! -e "$IR_NODE" ]; then
        log "IR node $IR_NODE not found, retrying in 2s..."
        sleep 2
        continue
    fi

    log "Starting getevent loop on $IR_NODE"
    getevent -lq "$IR_NODE" 2>/dev/null | while read -r line; do
        case "$line" in
            *MSC_SCAN*01cd328c*|*MSC_SCAN*00cd328c*)
                # Fire TV Volume UP
                log "FireTV IR: VOLUME UP detected"
                input keyevent 24
                ;;
            *MSC_SCAN*01cd328f*|*MSC_SCAN*00cd328f*)
                # Fire TV Volume DOWN
                log "FireTV IR: VOLUME DOWN detected"
                input keyevent 25
                ;;
        esac
    done

    log "getevent loop exited, restarting in 1s..."
    sleep 1
done
